//! 바로보기 창.
//! 속도는 `cargo run --release` 로 본다. 디버그 실행은 일부러 느리다.
//! JPG·PNG 디코더와 GPU만 창을 띄울 때 준비되고, SVG·GIF·변환·썸네일은 그때 호출된다.

#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

use std::path::{Path, PathBuf};
use std::sync::mpsc::{self, Receiver, Sender};
use std::time::Instant;

use baro::{convert, decode_still, list_images, load_thumb, sniff, visit_gif, Kind, OutFormat, Still};

enum Msg {
    Opened {
        path: PathBuf,
        image: Still,
        ms: f64,
        gif: bool,
        delay_ms: u32,
    },
    GifFrame(Still, u32),
    Thumb(usize, Still),
    Failed(String),
}

struct View {
    path: PathBuf,
    image: Still,
    ms: f64,
    gif: bool,
    frames: Vec<(Still, u32)>,
    frame: usize,
    playing: bool,
}

struct App {
    files: Vec<PathBuf>,
    index: usize,
    view: Option<View>,
    texture: Option<egui::TextureHandle>,
    thumbs: Vec<Option<egui::TextureHandle>>,
    error: Option<String>,
    explorer: bool,
    convert_open: bool,
    quality: u8,
    max_long: Option<u32>,
    format: OutFormat,
    zoom: f32,
    fit: bool,
    pan: egui::Vec2,
    rx: Receiver<Msg>,
    tx: Sender<Msg>,
    inflight: usize,
    thumb_queue: std::collections::VecDeque<usize>,
    thumb_started: Vec<bool>,
    play_acc: f32,
}

impl App {
    fn new(tx: Sender<Msg>, rx: Receiver<Msg>) -> Self {
        Self {
            files: Vec::new(),
            index: 0,
            view: None,
            texture: None,
            thumbs: Vec::new(),
            error: None,
            explorer: false,
            convert_open: false,
            quality: 90,
            max_long: None,
            format: OutFormat::Png,
            zoom: 1.0,
            fit: true,
            pan: egui::Vec2::ZERO,
            rx,
            tx,
            inflight: 0,
            thumb_queue: std::collections::VecDeque::new(),
            thumb_started: Vec::new(),
            play_acc: 0.0,
        }
    }

    fn set_files(&mut self, files: Vec<PathBuf>) {
        self.files = files;
        self.index = 0;
        self.thumbs.clear();
        self.thumb_started.clear();
        self.thumb_queue.clear();
        self.thumbs.resize(self.files.len(), None);
        self.thumb_started.resize(self.files.len(), false);
        self.explorer = self.files.len() > 1;
        if let Some(path) = self.files.first().cloned() {
            self.open(path);
        }
    }

    fn open(&mut self, path: PathBuf) {
        self.error = None;
        self.fit = true;
        self.pan = egui::Vec2::ZERO;
        self.play_acc = 0.0;
        let tx = self.tx.clone();
        std::thread::spawn(move || open_file(path, tx));
    }

    fn upload(&mut self, ctx: &egui::Context, image: &Still) {
        let color = egui::ColorImage::from_rgba_unmultiplied(
            [image.width as usize, image.height as usize],
            &image.rgba,
        );
        if let Some(tex) = &mut self.texture {
            tex.set(color, egui::TextureOptions::LINEAR);
        } else {
            self.texture = Some(ctx.load_texture("view", color, egui::TextureOptions::LINEAR));
        }
    }

    fn pump(&mut self, ctx: &egui::Context) {
        while let Ok(msg) = self.rx.try_recv() {
            match msg {
                Msg::Opened {
                    path,
                    image,
                    ms,
                    gif,
                    delay_ms,
                } => {
                    self.upload(ctx, &image);
                    let frames = if gif { vec![(image.clone(), delay_ms)] } else { Vec::new() };
                    self.view = Some(View {
                        path,
                        image,
                        ms,
                        gif,
                        frames,
                        frame: 0,
                        playing: false,
                    });
                }
                Msg::GifFrame(image, delay) => {
                    if let Some(view) = &mut self.view {
                        view.frames.push((image, delay));
                    }
                }
                Msg::Thumb(idx, image) => {
                    self.inflight = self.inflight.saturating_sub(1);
                    if idx < self.thumbs.len() {
                        let color = egui::ColorImage::from_rgba_unmultiplied(
                            [image.width as usize, image.height as usize],
                            &image.rgba,
                        );
                        self.thumbs[idx] =
                            Some(ctx.load_texture(format!("t{idx}"), color, egui::TextureOptions::LINEAR));
                    }
                }
                Msg::Failed(err) => {
                    self.inflight = self.inflight.saturating_sub(1);
                    self.error = Some(err);
                }
            }
        }
        self.kick_thumbs();
        let dt = ctx.input(|i| i.stable_dt);
        let mut acc = self.play_acc;
        let mut advance = None;
        let mut waiting = false;
        if let Some(view) = &mut self.view {
            if view.playing && view.frames.len() > 1 {
                acc += dt * 1000.0;
                let delay = view.frames[view.frame].1 as f32;
                if acc >= delay {
                    acc = 0.0;
                    view.frame = (view.frame + 1) % view.frames.len();
                    advance = Some(view.frames[view.frame].0.clone());
                } else {
                    waiting = true;
                }
            }
        }
        self.play_acc = acc;
        if let Some(image) = advance {
            self.upload(ctx, &image);
            ctx.request_repaint();
        } else if waiting {
            ctx.request_repaint_after(std::time::Duration::from_millis(16));
        }
    }

    fn kick_thumbs(&mut self) {
        while self.inflight < 2 {
            let Some(idx) = self.thumb_queue.pop_front() else {
                break;
            };
            if idx >= self.files.len() {
                continue;
            }
            self.inflight += 1;
            let path = self.files[idx].clone();
            let tx = self.tx.clone();
            std::thread::spawn(move || match load_thumb(&path) {
                Ok(image) => {
                    let _ = tx.send(Msg::Thumb(idx, image));
                }
                Err(err) => {
                    let _ = tx.send(Msg::Failed(err));
                }
            });
        }
    }

    fn want_thumb(&mut self, idx: usize) {
        if idx >= self.thumb_started.len() || self.thumb_started[idx] {
            return;
        }
        self.thumb_started[idx] = true;
        self.thumb_queue.push_back(idx);
    }

    fn save(&mut self) {
        let Some(view) = &self.view else { return };
        let stem = view.path.file_stem().and_then(|s| s.to_str()).unwrap_or("image");
        let name = format!("{stem}.{}", self.format.extension());
        let source = if view.gif {
            view.frames.first().map(|(image, _)| image).unwrap_or(&view.image).clone()
        } else {
            view.image.clone()
        };
        let format = self.format;
        let quality = self.quality;
        let max_long = self.max_long;
        let Some(path) = rfd::FileDialog::new()
            .set_file_name(&name)
            .add_filter("이미지", &[format.extension()])
            .save_file()
        else {
            return;
        };
        match convert(&source, format, quality, max_long) {
            Ok(bytes) => {
                if let Err(err) = std::fs::write(path, bytes) {
                    self.error = Some(err.to_string());
                }
            }
            Err(err) => self.error = Some(err),
        }
    }

    fn pick_files(&mut self) {
        if let Some(paths) = rfd::FileDialog::new()
            .add_filter("이미지", &["jpg", "jpeg", "png", "gif", "svg"])
            .pick_files()
        {
            self.set_files(paths);
        }
    }

    fn pick_folder(&mut self) {
        if let Some(dir) = rfd::FileDialog::new().pick_folder() {
            self.set_files(list_images(&dir));
        }
    }
}

fn open_file(path: PathBuf, tx: Sender<Msg>) {
    let bytes = match std::fs::read(&path) {
        Ok(bytes) => bytes,
        Err(err) => {
            let _ = tx.send(Msg::Failed(err.to_string()));
            return;
        }
    };
    let name = path.file_name().and_then(|n| n.to_str()).unwrap_or("");
    let kind = sniff(name, &bytes[..bytes.len().min(256)]);
    let started = Instant::now();
    if kind == Kind::Gif {
        let mut first = true;
        let result = visit_gif(&bytes, |frame| {
            if first {
                first = false;
                let _ = tx.send(Msg::Opened {
                    path: path.clone(),
                    image: frame.image,
                    ms: started.elapsed().as_secs_f64() * 1000.0,
                    gif: true,
                    delay_ms: frame.delay_ms,
                });
            } else {
                let _ = tx.send(Msg::GifFrame(frame.image, frame.delay_ms));
            }
        });
        if let Err(err) = result {
            if first {
                let _ = tx.send(Msg::Failed(err));
            }
        }
        return;
    }
    match decode_still(name, &bytes) {
        Ok(image) => {
            let _ = tx.send(Msg::Opened {
                path,
                image,
                ms: started.elapsed().as_secs_f64() * 1000.0,
                gif: false,
                delay_ms: 0,
            });
        }
        Err(err) => {
            let _ = tx.send(Msg::Failed(err));
        }
    }
}

impl eframe::App for App {
    fn update(&mut self, ctx: &egui::Context, _frame: &mut eframe::Frame) {
        self.pump(ctx);
        if ctx.input(|i| i.key_pressed(egui::Key::ArrowLeft)) && self.index > 0 {
            self.index -= 1;
            if let Some(path) = self.files.get(self.index).cloned() {
                self.open(path);
            }
        }
        if ctx.input(|i| i.key_pressed(egui::Key::ArrowRight)) && self.index + 1 < self.files.len() {
            self.index += 1;
            if let Some(path) = self.files.get(self.index).cloned() {
                self.open(path);
            }
        }
        if ctx.input(|i| i.key_pressed(egui::Key::F)) {
            self.fit = true;
            self.pan = egui::Vec2::ZERO;
        }
        if ctx.input(|i| i.key_pressed(egui::Key::Num1)) {
            self.fit = false;
            self.zoom = 1.0;
            self.pan = egui::Vec2::ZERO;
        }
        if ctx.input(|i| i.key_pressed(egui::Key::C)) {
            self.convert_open = !self.convert_open;
        }
        if ctx.input(|i| i.key_pressed(egui::Key::O)) {
            self.pick_files();
        }

        egui::TopBottomPanel::top("top").show(ctx, |ui| {
            ui.horizontal(|ui| {
                ui.label(egui::RichText::new("바로보기").strong());
                if ui.button("열기").clicked() {
                    self.pick_files();
                }
                if ui.button("폴더").clicked() {
                    self.pick_folder();
                }
                if let Some(view) = &self.view {
                    ui.label(file_label(&view.path));
                    ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                        ui.monospace(format!("{:.1}ms", view.ms));
                        ui.monospace(format!("{}×{}", view.image.width, view.image.height));
                    });
                } else {
                    ui.label("파일 없음");
                }
            });
        });

        egui::TopBottomPanel::bottom("bottom").show(ctx, |ui| {
            ui.horizontal(|ui| {
                if ui.add_enabled(self.index > 0, egui::Button::new("이전")).clicked() && self.index > 0 {
                    self.index -= 1;
                    if let Some(path) = self.files.get(self.index).cloned() {
                        self.open(path);
                    }
                }
                if ui
                    .add_enabled(self.index + 1 < self.files.len(), egui::Button::new("다음"))
                    .clicked()
                    && self.index + 1 < self.files.len()
                {
                    self.index += 1;
                    if let Some(path) = self.files.get(self.index).cloned() {
                        self.open(path);
                    }
                }
                if ui.button("맞춤").clicked() {
                    self.fit = true;
                    self.pan = egui::Vec2::ZERO;
                }
                if ui.button("1:1").clicked() {
                    self.fit = false;
                    self.zoom = 1.0;
                    self.pan = egui::Vec2::ZERO;
                }
                if ui.button("목록").clicked() {
                    self.explorer = !self.explorer;
                }
                let gif_toggle = self.view.as_ref().and_then(|view| {
                    view.gif.then_some((!view.frames.is_empty(), view.playing, view.frame, view.frames.len().max(1)))
                });
                if let Some((ready, playing, frame, total)) = gif_toggle {
                    let label = if playing { "일시정지" } else { "재생" };
                    if ui.add_enabled(ready, egui::Button::new(label)).clicked() {
                        if let Some(view) = &mut self.view {
                            view.playing = !view.playing;
                        }
                    }
                    ui.monospace(format!("{}/{}", frame + 1, total));
                }
                ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                    if ui.add_enabled(self.view.is_some(), egui::Button::new("변환")).clicked() {
                        self.convert_open = !self.convert_open;
                    }
                });
            });
        });

        if self.explorer && !self.files.is_empty() {
            let len = self.files.len();
            let names: Vec<String> = self.files.iter().map(|path| file_label(path)).collect();
            let mut pick = None;
            let mut wanted = Vec::new();
            egui::SidePanel::left("files").default_width(240.0).show(ctx, |ui| {
                egui::ScrollArea::vertical().show_rows(ui, 28.0, len, |ui, range| {
                    for idx in range {
                        wanted.push(idx);
                        ui.horizontal(|ui| {
                            let size = egui::vec2(24.0, 24.0);
                            if let Some(Some(tex)) = self.thumbs.get(idx) {
                                ui.image((tex.id(), size));
                            } else {
                                ui.allocate_space(size);
                            }
                            if ui.selectable_label(idx == self.index, &names[idx]).clicked() {
                                pick = Some(idx);
                            }
                        });
                    }
                });
            });
            for idx in wanted {
                self.want_thumb(idx);
            }
            if let Some(idx) = pick {
                self.index = idx;
                if let Some(path) = self.files.get(idx).cloned() {
                    self.open(path);
                }
            }
        }

        let (iw, ih, missing) = match &self.view {
            Some(view) => (view.image.width as f32, view.image.height as f32, false),
            None => (0.0, 0.0, true),
        };
        egui::CentralPanel::default().show(ctx, |ui| {
            if let Some(err) = &self.error {
                ui.colored_label(egui::Color32::from_rgb(224, 122, 106), err);
            }
            if missing {
                ui.centered_and_justified(|ui| {
                    ui.label("이미지를 열거나 폴더를 고르세요");
                });
                return;
            }
            let Some(tex_id) = self.texture.as_ref().map(|tex| tex.id()) else {
                return;
            };
            let rect = ui.available_rect_before_wrap();
            let response = ui.allocate_rect(rect, egui::Sense::click_and_drag());
            if response.dragged() {
                self.pan += response.drag_delta();
                self.fit = false;
            }
            let scroll = ui.input(|i| i.smooth_scroll_delta.y);
            if response.hovered() && scroll.abs() > 0.0 {
                self.fit = false;
                let factor = if scroll > 0.0 { 1.1 } else { 1.0 / 1.1 };
                self.zoom = (self.zoom * factor).clamp(0.05, 32.0);
            }
            let scale = if self.fit {
                (rect.width() / iw).min(rect.height() / ih)
            } else {
                self.zoom
            };
            let dest = egui::Rect::from_center_size(rect.center() + self.pan, egui::vec2(iw * scale, ih * scale));
            paint_checker(ui.painter(), dest);
            ui.painter().image(
                tex_id,
                dest,
                egui::Rect::from_min_max(egui::pos2(0.0, 0.0), egui::pos2(1.0, 1.0)),
                egui::Color32::WHITE,
            );
        });

        let mut do_save = false;
        if self.convert_open {
            let gif = self.view.as_ref().is_some_and(|view| view.gif);
            egui::Window::new("변환").collapsible(false).show(ctx, |ui| {
                ui.horizontal(|ui| {
                    for (fmt, label) in [(OutFormat::Png, "PNG"), (OutFormat::Jpeg, "JPEG"), (OutFormat::Webp, "WebP")] {
                        if ui.selectable_label(self.format == fmt, label).clicked() {
                            self.format = fmt;
                        }
                    }
                });
                ui.add_enabled(
                    self.format == OutFormat::Jpeg,
                    egui::Slider::new(&mut self.quality, 40..=100).text("품질"),
                );
                ui.horizontal(|ui| {
                    ui.label("긴 변");
                    for (label, value) in [("원본", None), ("1920", Some(1920u32)), ("1280", Some(1280)), ("800", Some(800))]
                    {
                        if ui.selectable_label(self.max_long == value, label).clicked() {
                            self.max_long = value;
                        }
                    }
                });
                if gif {
                    ui.label("GIF는 첫 프레임만 저장합니다.");
                }
                if ui.button("저장").clicked() {
                    do_save = true;
                }
            });
        }
        if do_save {
            self.save();
            self.convert_open = false;
        }
    }
}

fn file_label(path: &Path) -> String {
    path.file_name().and_then(|n| n.to_str()).unwrap_or("").to_string()
}

fn paint_checker(painter: &egui::Painter, rect: egui::Rect) {
    let cell = 16.0;
    let mut y = rect.top();
    let mut row = 0i32;
    while y < rect.bottom() {
        let mut x = rect.left();
        let mut col = 0i32;
        while x < rect.right() {
            let color = if (row + col) % 2 == 0 {
                egui::Color32::from_rgb(23, 22, 19)
            } else {
                egui::Color32::from_rgb(34, 31, 27)
            };
            painter.rect_filled(
                egui::Rect::from_min_max(
                    egui::pos2(x, y),
                    egui::pos2((x + cell).min(rect.right()), (y + cell).min(rect.bottom())),
                ),
                0.0,
                color,
            );
            x += cell;
            col += 1;
        }
        y += cell;
        row += 1;
    }
}

fn main() -> eframe::Result {
    let (tx, rx) = mpsc::channel();
    let options = eframe::NativeOptions {
        viewport: egui::ViewportBuilder::default().with_inner_size([1100.0, 720.0]),
        ..Default::default()
    };
    eframe::run_native(
        "바로보기",
        options,
        Box::new(|cc| {
            cc.egui_ctx.set_visuals(egui::Visuals::dark());
            Ok(Box::new(App::new(tx, rx)))
        }),
    )
}
